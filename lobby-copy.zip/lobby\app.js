const canvas = document.getElementById('gameCanvas');
const ctx = canvas.getContext('2d');
const lobbyMenuButton = document.getElementById('lobbyMenuButton');
const pauseOverlay = document.getElementById('pause-overlay');
const pauseMain = document.getElementById('pause-main');
const pausePlayButton = document.getElementById('pause-play');
const pauseSettingsButton = document.getElementById('pause-settings');
const pauseExitButton = document.getElementById('pause-exit');
const pauseSettingsPanel = document.getElementById('pause-settings-panel');
const pauseSettingsBackButton = document.getElementById('pause-settings-back');
const pauseExitPanel = document.getElementById('pause-exit-panel');
const pauseExitConfirmButton = document.getElementById('pause-exit-confirm');
const pauseExitCancelButton = document.getElementById('pause-exit-cancel');
const volumeKnob = document.getElementById('volume-knob');
const volumeKnobIndicator = document.getElementById('volume-knob-indicator');
const volumeLabel = document.getElementById('volume-label');
ctx.imageSmoothingEnabled = false;
const effectCanvas = document.createElement('canvas');
const effectCtx = effectCanvas.getContext('2d');
effectCtx.imageSmoothingEnabled = false;
const effectFrameCache = new Map();
let viewportWidth = window.innerWidth;
let viewportHeight = window.innerHeight;
let progressApi = null;
let currentUser = null;
let currentProfile = null;
let isSavingStats = false;
let paused = false;
let pauseVolume = 1;
let knobDragging = false;

const TILE_SIZE = 40;
const SOURCE_TILE_SIZE = 16;
const WORLD_WIDTH = 3040;
const TEST_GAME_ROOT = 'file:///C:/Users/k4lko/OneDrive/Documents/test%20game';

function gameRootPath(relativePath) {
    return `${TEST_GAME_ROOT}/${relativePath.replace(/^[./\\]+/, '').replace(/\\/g, '/')}`;
}

function hallokinAsset(relativePath) {
    return gameRootPath(`protagonist/Hallokin (protagonist)/${relativePath}`);
}

function npcAsset(relativePath) {
    return gameRootPath(`us npc/us npc/${relativePath}`);
}

function resizeCanvas() {
    viewportWidth = window.innerWidth;
    viewportHeight = window.innerHeight;

    const dpr = Math.max(1, Math.floor(window.devicePixelRatio || 1));
    canvas.width = viewportWidth * dpr;
    canvas.height = viewportHeight * dpr;
    canvas.style.width = `${viewportWidth}px`;
    canvas.style.height = `${viewportHeight}px`;

    ctx.setTransform(1, 0, 0, 1, 0, 0);
    ctx.scale(dpr, dpr);
    ctx.imageSmoothingEnabled = false;
}

resizeCanvas();
window.addEventListener('resize', resizeCanvas);

function getGameWidth() {
    return viewportWidth;
}

function getGameHeight() {
    return viewportHeight;
}

function getGroundLevel() {
    return getGameHeight() - 110;
}

const player = {
    x: 150,
    y: 0,
    width: 30,
    height: 50,
    speed: 6,
    velocityX: 0,
    velocityYGravity: 0,
    jumping: false,
    jumpPower: 15,
    gravity: 0.6,
    level: 1,
    health: 100,
    maxHealth: 100,
    mana: 100,
    maxMana: 100,
    stats: {
        health: 0,
        mana: 0,
        voidCyclone: 0,
        shadowStrike: 0
    },
    availableStatPoints: 0,
    facingRight: true,
    animationState: 'idle',
    action: null
};

player.y = getGroundLevel() - player.height;

const keys = {};

document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
        e.preventDefault();
        togglePause();
        return;
    }

    if (paused) {
        return;
    }

    keys[e.key.toLowerCase()] = true;

    if (e.key === ' ' || e.key === 'w' || e.key === 'W' || e.key === 'ArrowUp') {
        if (!player.jumping) {
            player.velocityYGravity = -player.jumpPower;
            player.jumping = true;
        }
    }

    if (e.key === 'e' || e.key === 'E') {
        handleInteraction();
    }

    if (e.key === 'j' || e.key === 'J') {
        triggerPlayerAction('attack');
    }

    if (e.key === 'q' || e.key === 'Q') {
        triggerPlayerAction('special');
    }

    if ((e.key === 'f' || e.key === 'F') && !document.getElementById('interactionPrompt')?.style.display?.includes('block')) {
        triggerPlayerAction('dash');
    }
});

document.addEventListener('keyup', (e) => {
    keys[e.key.toLowerCase()] = false;
});

document.getElementById('dialogueYes')?.addEventListener('click', () => {
    if (activeDialogueKey === 'lloyd' && activeDialogueMode === 'upgrade') {
        openStatsPanel();
        return;
    }

    if (activeDialogueKey === 'portal' && activeDialogueMode === 'portal') {
        window.location.href = getNextStagePath();
    }
});

document.getElementById('dialogueNo')?.addEventListener('click', () => {
    hideDialogue();
});

document.getElementById('statsClose')?.addEventListener('click', () => {
    hideStatsPanel();
});

document.getElementById('statsReset')?.addEventListener('click', () => {
    resetStats().catch((error) => {
        console.error('Failed to reset stats:', error);
    });
});

document.querySelectorAll('.stat-add').forEach((button) => {
    button.addEventListener('click', () => {
        upgradeStat(button.dataset.stat).catch((error) => {
            console.error('Failed to upgrade stat:', error);
        });
    });
});

function syncPausePanels(view = 'main') {
    if (!pauseMain || !pauseSettingsPanel || !pauseExitPanel) {
        return;
    }

    pauseMain.hidden = view !== 'main';
    pauseSettingsPanel.hidden = view !== 'settings';
    pauseExitPanel.hidden = view !== 'exit';
}

function syncPauseVolume() {
    const knobAngle = -135 + (pauseVolume * 270);

    if (volumeKnob) {
        volumeKnob.style.setProperty('--knob-angle', `${knobAngle}deg`);
        volumeKnob.setAttribute('aria-valuenow', String(Math.round(pauseVolume * 100)));
    }

    if (volumeKnobIndicator) {
        volumeKnobIndicator.style.setProperty('--knob-angle', `${knobAngle}deg`);
    }

    if (volumeLabel) {
        volumeLabel.textContent = `volume ${Math.round(pauseVolume * 100)}%`;
    }
}

function setPaused(nextPaused) {
    if (!pauseOverlay) {
        return;
    }

    paused = nextPaused;
    pauseOverlay.hidden = !paused;
    document.body.classList.toggle('is-paused', paused);

    if (paused) {
        syncPausePanels('main');
    } else {
        knobDragging = false;
    }

    syncPauseVolume();
}

function togglePause() {
    setPaused(!paused);
}

function updatePauseVolumeFromPointer(clientX, clientY) {
    if (!volumeKnob) {
        return;
    }

    const rect = volumeKnob.getBoundingClientRect();
    const centerX = rect.left + (rect.width / 2);
    const centerY = rect.top + (rect.height / 2);
    let knobAngle = (Math.atan2(clientY - centerY, clientX - centerX) * 180 / Math.PI) + 90;

    if (knobAngle > 180) {
        knobAngle -= 360;
    }

    knobAngle = Math.max(-135, Math.min(135, knobAngle));
    pauseVolume = Math.max(0, Math.min(1, (knobAngle + 135) / 270));
    syncPauseVolume();
}

lobbyMenuButton?.addEventListener('click', () => {
    togglePause();
});

pausePlayButton?.addEventListener('click', () => {
    setPaused(false);
});

pauseSettingsButton?.addEventListener('click', () => {
    syncPausePanels('settings');
});

pauseExitButton?.addEventListener('click', () => {
    syncPausePanels('exit');
});

pauseSettingsBackButton?.addEventListener('click', () => {
    syncPausePanels('main');
});

pauseExitCancelButton?.addEventListener('click', () => {
    syncPausePanels('main');
});

pauseExitConfirmButton?.addEventListener('click', () => {
    window.location.href = gameRootPath('ODYSSEY-main/indexPixel.html');
});

volumeKnob?.addEventListener('pointerdown', (event) => {
    event.preventDefault();
    knobDragging = true;
    volumeKnob.setPointerCapture?.(event.pointerId);
    updatePauseVolumeFromPointer(event.clientX, event.clientY);
});

window.addEventListener('pointermove', (event) => {
    if (!knobDragging) {
        return;
    }

    updatePauseVolumeFromPointer(event.clientX, event.clientY);
});

window.addEventListener('pointerup', () => {
    knobDragging = false;
});

window.addEventListener('pointercancel', () => {
    knobDragging = false;
});

const camera = {
    x: 0,
    y: 0
};

let lastFrameTime = performance.now();
let activeDialogueKey = null;
let activeDialogueMode = 'text';
const MAX_STAT_LEVEL = 500;

function getPlatforms() {
    return [
        { x: 0, y: getGroundLevel(), width: WORLD_WIDTH, height: 150, type: 'ground' }
    ];
}

function loadImage(src) {
    const image = new Image();
    image.src = src;
    return image;
}

function loadImageSeries(folder, count) {
    return Array.from({ length: count }, (_, index) => loadImage(`${folder}/${index + 1}.png`));
}

const backgroundImage = loadImage('background.png');
const tilesetImage = loadImage('Tileset.png');
const dimensionalPortalImage = loadImage('Dimensional_Portal.png');
const cloudImages = [
    loadImage('Clouds_black/Shape1/cloud_shape1_1.png'),
    loadImage('Clouds_black/Shape3/cloud_shape3_2.png'),
    loadImage('Clouds_black/Shape5/cloud_shape5_3.png'),
    loadImage('Clouds_black/Shape8/clouds_shape8_1.png')
];
let backgroundFailed = false;
backgroundImage.onerror = () => {
    backgroundFailed = true;
};

const groundTiles = {
    top: { col: 0, row: 0 },
    fill: { col: 0, row: 1 }
};
const GROUND_TILE_DRAW_SIZE = 32;

const hallokinSheets = {
    idle: loadImage(hallokinAsset('png (free)/idle.png')),
    run: loadImage(hallokinAsset('png (free)/run.png')),
    jump: loadImage(hallokinAsset('png (free)/jump.png')),
    fall: loadImage(hallokinAsset('png (free)/fall.png')),
    attack: loadImage(hallokinAsset('png (free)/attack-2.png')),
    special: loadImage(hallokinAsset('png (free)/attack up.png')),
    dash: loadImage(hallokinAsset('png (free)/jump - attack forwared.png'))
};

const hallokinAnimations = {
    idle: {
        image: hallokinSheets.idle,
        frameWidth: 96,
        frameHeight: 128,
        frameOrder: [0, 2, 4, 6, 8, 10],
        fps: 10,
        scale: 4.2,
        trim: { x: 36, y: 48, width: 40, height: 36 },
        anchorX: 20,
        groundOffset: 16.8,
        effect: 'hallokinShadowHero'
    },
    run: {
        image: hallokinSheets.run,
        frameWidth: 96,
        frameHeight: 128,
        frameOrder: [0, 2, 4, 6],
        fps: 12,
        scale: 4.2,
        trim: { x: 34, y: 48, width: 42, height: 36 },
        anchorX: 22,
        groundOffset: 18,
        effect: 'hallokinShadowHero'
    },
    jump: {
        image: hallokinSheets.jump,
        frameWidth: 96,
        frameHeight: 128,
        frameOrder: [0, 2, 4],
        fps: 12,
        scale: 4.2,
        trim: { x: 32, y: 44, width: 44, height: 40 },
        anchorX: 24,
        groundOffset: 18,
        effect: 'hallokinShadowHero'
    },
    fall: {
        image: hallokinSheets.fall,
        frameWidth: 96,
        frameHeight: 128,
        frameOrder: [0, 2, 4],
        fps: 12,
        scale: 4.2,
        trim: { x: 32, y: 44, width: 44, height: 40 },
        anchorX: 24,
        groundOffset: 18,
        effect: 'hallokinShadowHero'
    },
    attack: {
        image: hallokinSheets.attack,
        frameWidth: 96,
        frameHeight: 128,
        frameOrder: [0, 0, 2, 4, 6],
        fps: 18,
        scale: 4.2,
        trim: { x: 22, y: 44, width: 70, height: 40 },
        anchorX: 34,
        groundOffset: 18,
        effect: 'hallokinShadowHero'
    },
    special: {
        image: hallokinSheets.special,
        frameWidth: 96,
        frameHeight: 128,
        frameOrder: [0, 0, 2, 4, 6, 8, 10],
        fps: 14,
        scale: 4.2,
        trim: { x: 18, y: 14, width: 62, height: 66 },
        anchorX: 34,
        anchorY: 65,
        groundOffset: 18,
        effect: 'hallokinShadowHero'
    },
    dash: {
        image: hallokinSheets.dash,
        frameWidth: 96,
        frameHeight: 128,
        frameOrder: [0, 0, 2, 4, 6, 8],
        fps: 21,
        scale: 4.2,
        trim: { x: 14, y: 30, width: 80, height: 46 },
        anchorX: 34,
        anchorY: 45,
        groundOffset: 18,
        effect: 'hallokinShadowHero'
    }
};

const HALL0KIN_HERO_PALETTE = {
    abyss: [4, 5, 8],
    deep: [11, 15, 24],
    core: [24, 31, 48],
    edge: [41, 55, 84],
    glow: [85, 111, 164],
    face: [224, 230, 240]
};

const playerActionRules = {
    attack: { duration: 5 / 18, manaCost: 0 },
    special: { duration: 7 / 14, manaCost: 10 },
    dash: { duration: 6 / 21, manaCost: 8 }
};

const npcSprites = {
    drew: {
        idle: { image: loadImage(npcAsset('drew/Idle.png')), frameWidth: 128, frameHeight: 128, frames: 7, fps: 8, scale: 2.1 },
        idle2: { image: loadImage(npcAsset('drew/Idle_2.png')), frameWidth: 128, frameHeight: 128, frames: 8, fps: 8, scale: 2.1 },
        walk: { image: loadImage(npcAsset('drew/Walk.png')), frameWidth: 128, frameHeight: 128, frames: 10, fps: 10, scale: 2.1 },
        run: { image: loadImage(npcAsset('drew/Run.png')), frameWidth: 128, frameHeight: 128, frames: 8, fps: 11, scale: 2.1 },
        jump: { image: loadImage(npcAsset('drew/Jump.png')), frameWidth: 128, frameHeight: 128, frames: 4, fps: 8, scale: 2.1 },
        hurt: { image: loadImage(npcAsset('drew/Hurt.png')), frameWidth: 128, frameHeight: 128, frames: 3, fps: 8, scale: 2.1 },
        attack1: { image: loadImage(npcAsset('drew/Attack_1.png')), frameWidth: 128, frameHeight: 128, frames: 6, fps: 10, scale: 2.1 },
        attack2: { image: loadImage(npcAsset('drew/Attack_2.png')), frameWidth: 128, frameHeight: 128, frames: 6, fps: 10, scale: 2.1 },
        attack3: { image: loadImage(npcAsset('drew/Attack_3.png')), frameWidth: 128, frameHeight: 128, frames: 6, fps: 10, scale: 2.1 },
        dead: { image: loadImage(npcAsset('drew/Dead.png')), frameWidth: 128, frameHeight: 128, frames: 5, fps: 7, scale: 2.1, holdLast: true }
    },
    martin: {
        idle: { image: loadImage(npcAsset('martin/Idle.png')), frameWidth: 128, frameHeight: 128, frames: 5, fps: 8, scale: 2.1 },
        walk: { image: loadImage(npcAsset('martin/Walk.png')), frameWidth: 128, frameHeight: 128, frames: 8, fps: 9, scale: 2.1 },
        run: { image: loadImage(npcAsset('martin/Run.png')), frameWidth: 128, frameHeight: 128, frames: 8, fps: 10, scale: 2.1 },
        jump: { image: loadImage(npcAsset('martin/Jump.png')), frameWidth: 128, frameHeight: 128, frames: 4, fps: 8, scale: 2.1 },
        hurt: { image: loadImage(npcAsset('martin/Hurt.png')), frameWidth: 128, frameHeight: 128, frames: 3, fps: 8, scale: 2.1 },
        protect: { image: loadImage(npcAsset('martin/Protect.png')), frameWidth: 128, frameHeight: 128, frames: 6, fps: 8, scale: 2.1 },
        attack1: { image: loadImage(npcAsset('martin/Attack_1.png')), frameWidth: 128, frameHeight: 128, frames: 6, fps: 10, scale: 2.1 },
        attack2: { image: loadImage(npcAsset('martin/Attack_2.png')), frameWidth: 128, frameHeight: 128, frames: 6, fps: 10, scale: 2.1 },
        attack3: { image: loadImage(npcAsset('martin/Attack_3.png')), frameWidth: 128, frameHeight: 128, frames: 6, fps: 10, scale: 2.1 },
        dead: { image: loadImage(npcAsset('martin/Dead.png')), frameWidth: 128, frameHeight: 128, frames: 5, fps: 7, scale: 2.1, holdLast: true }
    },
    lloyd: {
        idle: { image: loadImage(npcAsset('lloyd/Idle.png')), frameWidth: 128, frameHeight: 128, frames: 14, fps: 8, scale: 2.1 },
        idle2: { image: loadImage(npcAsset('lloyd/Idle_2.png')), frameWidth: 128, frameHeight: 128, frames: 5, fps: 7, scale: 2.1 },
        idle3: { image: loadImage(npcAsset('lloyd/Idle_3.png')), frameWidth: 128, frameHeight: 128, frames: 6, fps: 7, scale: 2.1 },
        dialogue: { image: loadImage(npcAsset('lloyd/Dialogue.png')), frameWidth: 128, frameHeight: 128, frames: 4, fps: 6, scale: 2.1 },
        approval: { image: loadImage(npcAsset('lloyd/Approval.png')), frameWidth: 128, frameHeight: 128, frames: 4, fps: 6, scale: 2.1 }
    }
};

const npcInstances = [
    {
        key: 'drew',
        name: 'Drew',
        x: 1180,
        y: 0,
        width: 70,
        height: 108,
        facingRight: false,
        animationTime: 0,
        animationIndex: 0,
        cycleTime: 0,
        sequence: ['idle'],
        dialogue: 'That portal scares me... it feels like it could drag someone into a place they may never return from.'
    },
    {
        key: 'lloyd',
        name: 'Lloyd',
        x: 1860,
        y: 0,
        width: 70,
        height: 108,
        facingRight: true,
        animationTime: 0,
        animationIndex: 0,
        cycleTime: 0,
        sequence: ['idle'],
        dialogue: 'Do you want to upgrade before you leave?'
    },
    {
        key: 'martin',
        name: 'Martin',
        x: 2580,
        y: 0,
        width: 70,
        height: 108,
        facingRight: false,
        animationTime: 0,
        animationIndex: 0,
        cycleTime: 0,
        sequence: ['idle'],
        dialogue: 'You know that portal will take you somewhere filled with monsters... if you step through it, be ready to fight.'
    }
];

const dimensionalPortal = {
    x: 50,
    groundOffset: 8,
    scale: 6.2,
    frameWidth: 32,
    frameHeight: 32,
    frames: [
        { x: 0, y: 0 },
        { x: 32, y: 0 },
        { x: 64, y: 0 },
        { x: 0, y: 32 },
        { x: 32, y: 32 },
        { x: 64, y: 32 }
    ],
    fps: 9
};

npcInstances.forEach((npc) => {
    npc.y = getGroundLevel() - npc.height;
});

function getObjects() {
    const portalWidth = dimensionalPortal.frameWidth * dimensionalPortal.scale;
    const portalHeight = dimensionalPortal.frameHeight * dimensionalPortal.scale;
    const portalY = getGroundLevel() - portalHeight + dimensionalPortal.groundOffset;

    return [{
        key: 'portal',
        name: 'Dimensional Portal',
        x: dimensionalPortal.x - (portalWidth * 0.5),
        y: portalY,
        width: portalWidth,
        height: portalHeight,
        type: 'portal',
        dialogue: 'The portal hums with a dangerous pull, like it leads somewhere dark and unforgiving.'
    }, ...npcInstances.map((npc) => ({
        key: npc.key,
        name: npc.name,
        x: npc.x,
        y: npc.y,
        width: npc.width,
        height: npc.height,
        type: 'npc',
        dialogue: npc.dialogue
    }))];
}

function updateCamera() {
    const gameWidth = getGameWidth();
    camera.x = Math.max(0, Math.min(player.x - gameWidth * 0.45, WORLD_WIDTH - gameWidth));
    camera.y = 0;
}

function checkPlatformCollision(rect, platform) {
    return rect.x < platform.x + platform.width &&
        rect.x + rect.width > platform.x &&
        rect.y + rect.height <= platform.y + 10 &&
        rect.y + rect.height + rect.velocityYGravity > platform.y;
}

function updatePlayer(deltaFactor) {
    if (player.action) {
        player.action.time += deltaFactor / 60;
        if (player.action.time >= player.action.duration) {
            player.action = null;
        }
    }

    player.velocityX = 0;

    if ((keys.a || keys.arrowleft) && !player.action) {
        player.velocityX = -player.speed * deltaFactor;
        player.facingRight = false;
    }

    if ((keys.d || keys.arrowright) && !player.action) {
        player.velocityX = player.speed * deltaFactor;
        player.facingRight = true;
    }

    player.velocityYGravity += player.gravity * deltaFactor;
    if (player.velocityYGravity > 15 * deltaFactor) {
        player.velocityYGravity = 15 * deltaFactor;
    }

    player.x += player.velocityX;
    player.y += player.velocityYGravity;

    if (player.x < 0) {
        player.x = 0;
    }

    if (player.x + player.width > WORLD_WIDTH) {
        player.x = WORLD_WIDTH - player.width;
    }

    const platforms = getPlatforms();
    platforms.forEach((platform) => {
        if (checkPlatformCollision(player, platform) && player.velocityYGravity > 0) {
            player.y = platform.y - player.height;
            player.velocityYGravity = 0;
            player.jumping = false;
        }
    });

    if (player.y < 0) {
        player.y = 0;
        player.velocityYGravity = 0;
    }

    if (player.action) {
        player.animationState = player.action.name;
    } else if (player.jumping) {
        player.animationState = player.velocityYGravity < 0 ? 'jump' : 'fall';
    } else if (Math.abs(player.velocityX) > 0.2) {
        player.animationState = 'run';
    } else {
        player.animationState = 'idle';
    }
}

function triggerPlayerAction(actionName) {
    const rule = playerActionRules[actionName];
    if (!rule || player.action) {
        return;
    }

    if (rule.manaCost > 0 && player.mana < rule.manaCost) {
        return;
    }

    player.mana = Math.max(0, player.mana - rule.manaCost);
    player.action = {
        name: actionName,
        time: 0,
        duration: rule.duration
    };
}

function updateNPCs(deltaFactor) {
    npcInstances.forEach((npc) => {
        const animationKey = npc.sequence[npc.animationIndex];
        const animation = npcSprites[npc.key]?.[animationKey];
        if (!animation) {
            return;
        }

        const deltaSeconds = deltaFactor / 60;
        const frameCount = animation.frameOrder?.length ?? animation.frames ?? 1;
        const animationDuration = Math.max(frameCount / animation.fps, 0.55);
        const holdTime = animation.holdLast ? 0.35 : 0.18;

        npc.animationTime += deltaSeconds;
        npc.cycleTime += deltaSeconds;

        if (npc.cycleTime >= animationDuration + holdTime) {
            npc.cycleTime = 0;
            npc.animationTime = 0;
            npc.animationIndex = (npc.animationIndex + 1) % npc.sequence.length;
        }
    });
}

function distance(a, b) {
    const dx = (a.x + a.width / 2) - (b.x + b.width / 2);
    const dy = (a.y + a.height / 2) - (b.y + b.height / 2);
    return Math.sqrt(dx * dx + dy * dy);
}

function checkNearbyInteractions() {
    const interactionRange = 80;
    const objects = getObjects();
    const nearbyEntity = objects.find((obj) => distance(player, obj) < interactionRange);
    const prompt = document.getElementById('interactionPrompt');
    if (prompt) {
        prompt.innerHTML = nearbyEntity
            ? (nearbyEntity.type === 'portal'
                ? `Press <strong>E</strong> to approach <strong>${nearbyEntity.name}</strong>`
                : `Press <strong>E</strong> to talk to <strong>${nearbyEntity.name}</strong>`)
            : 'Press <strong>E</strong> to interact';
        prompt.style.display = nearbyEntity ? 'block' : 'none';
    }

    if (activeDialogueKey && (!nearbyEntity || nearbyEntity.key !== activeDialogueKey)) {
        hideDialogue();
    }
}

function handleInteraction() {
    const interactionRange = 80;
    const objects = getObjects();

    for (const obj of objects) {
        if (distance(player, obj) < interactionRange) {
            if (activeDialogueKey === obj.key) {
                hideDialogue();
            } else {
                if (obj.key === 'portal') {
                    showPortalPrompt(obj.name, obj.key);
                } else if (obj.key === 'lloyd') {
                    showUpgradePrompt(obj.name, obj.key);
                } else {
                    showDialogue(obj.name, obj.dialogue, obj.key);
                }
            }
            return;
        }
    }

    hideDialogue();
}

function drawRepeatedImage(image, x, y, width, height, tileWidth = TILE_SIZE, tileHeight = TILE_SIZE) {
    const columns = Math.ceil(width / tileWidth);
    const rows = Math.ceil(height / tileHeight);

    for (let row = 0; row < rows; row++) {
        for (let col = 0; col < columns; col++) {
            const dx = x + col * tileWidth;
            const dy = y + row * tileHeight;
            const dw = Math.min(tileWidth, x + width - dx);
            const dh = Math.min(tileHeight, y + height - dy);
            ctx.drawImage(image, dx, dy, dw, dh);
        }
    }
}

function drawRepeatedTilesetTile(tile, x, y, width, height, tileWidth = TILE_SIZE, tileHeight = TILE_SIZE) {
    if (!tilesetImage.complete || tilesetImage.naturalWidth <= 0) {
        return;
    }

    const columns = Math.ceil(width / tileWidth);
    const rows = Math.ceil(height / tileHeight);
    const sourceX = tile.col * SOURCE_TILE_SIZE;
    const sourceY = tile.row * SOURCE_TILE_SIZE;

    for (let row = 0; row < rows; row++) {
        for (let col = 0; col < columns; col++) {
            const dx = x + col * tileWidth;
            const dy = y + row * tileHeight;
            const dw = Math.min(tileWidth, x + width - dx);
            const dh = Math.min(tileHeight, y + height - dy);

            ctx.drawImage(
                tilesetImage,
                sourceX,
                sourceY,
                SOURCE_TILE_SIZE,
                SOURCE_TILE_SIZE,
                dx,
                dy,
                dw,
                dh
            );
        }
    }
}

function stableNoise(value) {
    return Math.abs(Math.sin(value * 12.9898) * 43758.5453) % 1;
}

function drawCloudLayer(gameWidth, gameHeight) {
    const cloudTime = performance.now() * 0.015;
    const clouds = [
        { image: cloudImages[0], worldX: 180, y: 55, width: 190, speed: 0.08, alpha: 0.34, drift: 0.38 },
        { image: cloudImages[1], worldX: 980, y: 100, width: 240, speed: 0.12, alpha: 0.3, drift: 0.48 },
        { image: cloudImages[2], worldX: 1880, y: 70, width: 210, speed: 0.1, alpha: 0.26, drift: 0.34 },
        { image: cloudImages[3], worldX: 2860, y: 120, width: 260, speed: 0.09, alpha: 0.3, drift: 0.42 },
        { image: cloudImages[1], worldX: 4020, y: 80, width: 225, speed: 0.11, alpha: 0.24, drift: 0.3 },
        { image: cloudImages[0], worldX: 5280, y: 130, width: 185, speed: 0.07, alpha: 0.28, drift: 0.28 }
    ];

    clouds.forEach((cloud) => {
        const image = cloud.image;
        if (!image.complete || image.naturalWidth <= 0) {
            return;
        }

        const parallaxX = cloud.worldX + cloudTime * cloud.drift - camera.x * cloud.speed;
        const wrappedX = ((parallaxX % (WORLD_WIDTH + 600)) + (WORLD_WIDTH + 600)) % (WORLD_WIDTH + 600);
        const screenX = wrappedX - 300;
        const drawHeight = (image.naturalHeight / image.naturalWidth) * cloud.width;

        if (screenX > gameWidth + 260 || screenX + cloud.width < -260 || cloud.y > gameHeight * 0.6) {
            return;
        }

        ctx.save();
        ctx.globalAlpha = cloud.alpha;
        ctx.drawImage(image, screenX, cloud.y, cloud.width, drawHeight);
        ctx.globalAlpha = cloud.alpha * 0.35;
        ctx.drawImage(image, screenX, cloud.y, cloud.width, drawHeight);
        ctx.restore();
    });
}

function drawBackground() {
    const gameWidth = getGameWidth();
    const gameHeight = getGameHeight();
    const groundLevel = getGroundLevel();

    if (backgroundImage.complete && backgroundImage.naturalWidth > 0) {
        const scale = gameHeight / backgroundImage.naturalHeight;
        const drawWidth = backgroundImage.naturalWidth * scale;
        const drawHeight = backgroundImage.naturalHeight * scale;
        const drawY = 0;
        const offsetX = (camera.x * 0.25) % drawWidth;
        let startX = -offsetX;

        while (startX < gameWidth) {
            ctx.drawImage(backgroundImage, startX, drawY, drawWidth, drawHeight);
            startX += drawWidth;
        }
    } else {
        const gradient = ctx.createLinearGradient(0, 0, 0, gameHeight);
        gradient.addColorStop(0, '#3c6fb6');
        gradient.addColorStop(0.55, '#7aa8d8');
        gradient.addColorStop(1, '#d8eefc');
        ctx.fillStyle = gradient;
        ctx.fillRect(0, 0, gameWidth, gameHeight);

        if (backgroundFailed) {
            ctx.fillStyle = 'rgba(255, 255, 255, 0.2)';
            ctx.font = '20px Arial';
            ctx.fillText('background.png failed to load', 24, 36);
        }
    }

    drawCloudLayer(gameWidth, gameHeight);

    if (tilesetImage.complete && tilesetImage.naturalWidth > 0) {
        drawRepeatedTilesetTile(
            groundTiles.fill,
            0,
            groundLevel + 8,
            gameWidth,
            gameHeight - groundLevel,
            GROUND_TILE_DRAW_SIZE,
            GROUND_TILE_DRAW_SIZE
        );
        drawRepeatedTilesetTile(
            groundTiles.top,
            0,
            groundLevel,
            gameWidth,
            GROUND_TILE_DRAW_SIZE,
            GROUND_TILE_DRAW_SIZE,
            GROUND_TILE_DRAW_SIZE
        );

        ctx.fillStyle = 'rgba(20, 34, 24, 0.18)';
        ctx.fillRect(0, groundLevel + GROUND_TILE_DRAW_SIZE, gameWidth, gameHeight - groundLevel - GROUND_TILE_DRAW_SIZE);
    } else {
        ctx.fillStyle = '#5d8f45';
        ctx.fillRect(0, groundLevel, gameWidth, gameHeight - groundLevel);

        ctx.fillStyle = '#8fcf63';
        ctx.fillRect(0, groundLevel, gameWidth, 12);
    }

}

function drawPlatforms() {
    return;
}

function drawObjects() {
    drawDimensionalPortal();

    const objects = getObjects();

    objects.forEach((obj) => {
        if (obj.type === 'npc' || obj.type === 'portal') {
            return;
        }

        const screenX = obj.x - camera.x;
        const screenY = obj.y;

        ctx.fillStyle = 'rgba(0, 0, 0, 0.2)';
        ctx.beginPath();
        ctx.ellipse(screenX + obj.width / 2, screenY + obj.height + 5, obj.width / 2, 5, 0, 0, Math.PI * 2);
        ctx.fill();

        ctx.fillStyle = '#6c5440';
        ctx.fillRect(screenX, screenY, obj.width, obj.height);
        ctx.strokeStyle = '#2d1810';
        ctx.lineWidth = 2;
        ctx.strokeRect(screenX, screenY, obj.width, obj.height);

        if (obj.icon) {
            ctx.fillStyle = '#d4af37';
            ctx.font = 'bold 16px Arial';
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';
            ctx.fillText(obj.icon, screenX + obj.width / 2, screenY + obj.height / 2);
        }
    });
}

function drawDimensionalPortal() {
    const groundLevel = getGroundLevel();
    const screenX = dimensionalPortal.x - camera.x;
    const time = performance.now() * 0.001;
    const bobOffset = Math.sin(time * 4.5) * 3;
    const pulse = (Math.sin(time * 6.8) + 1) * 0.5;
    const auraScale = 1 + (pulse * 0.14);

    if (dimensionalPortalImage.complete && dimensionalPortalImage.naturalWidth > 0) {
        const frameIndex = Math.floor(time * dimensionalPortal.fps) % dimensionalPortal.frames.length;
        const frame = dimensionalPortal.frames[frameIndex];
        const drawWidth = dimensionalPortal.frameWidth * dimensionalPortal.scale;
        const drawHeight = dimensionalPortal.frameHeight * dimensionalPortal.scale;
        const drawX = Math.round(screenX - (drawWidth * 0.5));
        const drawY = Math.round(groundLevel - drawHeight + dimensionalPortal.groundOffset + bobOffset);

        ctx.save();
        ctx.globalAlpha = 0.24 + (pulse * 0.18);
        ctx.fillStyle = '#0b0318';
        ctx.beginPath();
        ctx.ellipse(screenX, groundLevel + 2, drawWidth * (0.18 + pulse * 0.04), 12 + pulse * 3, 0, 0, Math.PI * 2);
        ctx.fill();

        ctx.globalAlpha = 0.16 + (pulse * 0.2);
        ctx.fillStyle = '#6a2cff';
        ctx.beginPath();
        ctx.ellipse(screenX, drawY + drawHeight * 0.52, drawWidth * 0.28 * auraScale, drawHeight * 0.34 * auraScale, 0, 0, Math.PI * 2);
        ctx.fill();

        ctx.globalAlpha = 0.12 + (pulse * 0.16);
        ctx.strokeStyle = '#b176ff';
        ctx.lineWidth = 4;
        ctx.beginPath();
        ctx.ellipse(screenX, drawY + drawHeight * 0.52, drawWidth * 0.22 * auraScale, drawHeight * 0.28 * auraScale, 0, 0, Math.PI * 2);
        ctx.stroke();

        ctx.globalAlpha = 0.92 + (pulse * 0.08);
        ctx.drawImage(
            dimensionalPortalImage,
            frame.x,
            frame.y,
            dimensionalPortal.frameWidth,
            dimensionalPortal.frameHeight,
            drawX,
            drawY,
            Math.round(drawWidth),
            Math.round(drawHeight)
        );
        ctx.restore();
        return;
    }

    ctx.save();
    ctx.globalAlpha = 0.45 + (pulse * 0.18);
    ctx.fillStyle = 'rgba(97, 37, 181, 0.45)';
    ctx.beginPath();
    ctx.ellipse(screenX, groundLevel - 34 + bobOffset, 26 * auraScale, 42 * auraScale, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = 'rgba(178, 111, 255, 0.9)';
    ctx.lineWidth = 4;
    ctx.stroke();
    ctx.restore();
}

function drawBuildings() {
    return;
}

function drawNPCs() {
    npcInstances.forEach((npc) => {
        const animation = npcSprites[npc.key][npc.sequence[npc.animationIndex]];
        drawAnimatedSprite(animation, npc.x + (npc.width / 2), npc.y + npc.height, npc.facingRight, npc.animationTime, 0.24);
    });
}

function drawPlayer() {
    const animation = hallokinAnimations[player.animationState] ?? hallokinAnimations.idle;
    const animationTime = player.action ? player.action.time : performance.now() / 1000;
    drawAnimatedSprite(animation, player.x + (player.width / 2), player.y + player.height, player.facingRight, animationTime, 0.2);
}

function mixPalette(level, start, end) {
    return [
        Math.round(start[0] + ((end[0] - start[0]) * level)),
        Math.round(start[1] + ((end[1] - start[1]) * level)),
        Math.round(start[2] + ((end[2] - start[2]) * level))
    ];
}

function clamp(value, min, max) {
    return Math.max(min, Math.min(max, value));
}

function createHallokinShadowFrame(image, sourceX, sourceY, sourceWidth, sourceHeight) {
    const cacheKey = [image.src, sourceX, sourceY, sourceWidth, sourceHeight, 'hallokinShadowHero'].join('|');
    if (effectFrameCache.has(cacheKey)) {
        return effectFrameCache.get(cacheKey);
    }

    effectCanvas.width = sourceWidth;
    effectCanvas.height = sourceHeight;
    effectCtx.clearRect(0, 0, sourceWidth, sourceHeight);
    effectCtx.drawImage(image, sourceX, sourceY, sourceWidth, sourceHeight, 0, 0, sourceWidth, sourceHeight);

    const imageData = effectCtx.getImageData(0, 0, sourceWidth, sourceHeight);
    const { data } = imageData;

    for (let i = 0; i < data.length; i += 4) {
        if (data[i + 3] === 0) {
            continue;
        }

        const red = data[i];
        const green = data[i + 1];
        const blue = data[i + 2];
        const maxChannel = Math.max(red, green, blue);
        const minChannel = Math.min(red, green, blue);
        const saturation = maxChannel - minChannel;
        const luminance = (red * 0.299) + (green * 0.587) + (blue * 0.114);
        const isFaceLight = luminance > 128 && red >= green && green >= blue && saturation < 78;
        const isWarmSlash = red >= 110 && red > (green + 12) && green >= 45 && blue <= 145 && saturation >= 22;
        let mapped;

        if (isFaceLight) {
            mapped = mixPalette(clamp((luminance - 128) / 100, 0, 1), HALL0KIN_HERO_PALETTE.glow, HALL0KIN_HERO_PALETTE.face);
        } else if (isWarmSlash) {
            mapped = mixPalette(clamp((luminance - 72) / 128, 0, 1), HALL0KIN_HERO_PALETTE.deep, HALL0KIN_HERO_PALETTE.glow);
        } else if (luminance > 120) {
            mapped = mixPalette(clamp((luminance - 120) / 90, 0, 1), HALL0KIN_HERO_PALETTE.core, HALL0KIN_HERO_PALETTE.glow);
        } else if (luminance > 70) {
            mapped = mixPalette(clamp((luminance - 70) / 50, 0, 1), HALL0KIN_HERO_PALETTE.deep, HALL0KIN_HERO_PALETTE.edge);
        } else if (luminance > 26) {
            mapped = mixPalette(clamp((luminance - 26) / 44, 0, 1), HALL0KIN_HERO_PALETTE.abyss, HALL0KIN_HERO_PALETTE.core);
        } else {
            mapped = HALL0KIN_HERO_PALETTE.abyss;
        }

        data[i] = mapped[0];
        data[i + 1] = mapped[1];
        data[i + 2] = mapped[2];
    }

    effectCtx.putImageData(imageData, 0, 0);

    const frameCanvas = document.createElement('canvas');
    frameCanvas.width = sourceWidth;
    frameCanvas.height = sourceHeight;
    const frameCtx = frameCanvas.getContext('2d');
    frameCtx.imageSmoothingEnabled = false;
    frameCtx.drawImage(effectCanvas, 0, 0);
    effectFrameCache.set(cacheKey, frameCanvas);
    return frameCanvas;
}

function drawAnimatedSprite(animation, worldCenterX, worldFootY, facingRight, timeSeconds, shadowScale = 0.18) {
    if (!animation || !animation.image.complete || animation.image.naturalWidth <= 0) {
        return;
    }

    const frames = animation.frameOrder ?? Array.from({ length: animation.frames }, (_, index) => index);
    const frameBase = Math.floor(timeSeconds * animation.fps);
    const frameIndex = animation.holdLast ? Math.min(frameBase, frames.length - 1) : (frameBase % frames.length);
    const sourceFrame = frames[frameIndex];
    const trim = animation.trim;
    let sourceX = sourceFrame * animation.frameWidth;
    let sourceY = 0;
    let sourceWidth = animation.frameWidth;
    let sourceHeight = animation.frameHeight;
    let drawWidth = animation.frameWidth * animation.scale;
    let drawHeight = animation.frameHeight * animation.scale;
    const screenX = worldCenterX - camera.x;
    let drawY = worldFootY - drawHeight;

    if (trim) {
        sourceX += trim.x;
        sourceY = trim.y;
        sourceWidth = trim.width;
        sourceHeight = trim.height;
        drawWidth = trim.width * animation.scale;
        drawHeight = trim.height * animation.scale;
        drawY = animation.anchorY != null
            ? worldFootY - (animation.anchorY * animation.scale)
            : worldFootY - drawHeight + (animation.groundOffset ?? 0);
    }

    const renderImage = animation.effect === 'hallokinShadowHero'
        ? createHallokinShadowFrame(animation.image, sourceX, sourceY, sourceWidth, sourceHeight)
        : animation.image;
    const anchorX = (animation.anchorX ?? ((trim?.width ?? animation.frameWidth) * 0.5)) * animation.scale;

    ctx.save();
    ctx.fillStyle = 'rgba(0, 0, 0, 0.2)';
    ctx.beginPath();
    ctx.ellipse(screenX, worldFootY - 4, drawWidth * shadowScale, 6, 0, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();

    ctx.save();
    ctx.translate(Math.round(screenX), Math.round(drawY));
    ctx.scale(facingRight ? 1 : -1, 1);
    ctx.drawImage(
        renderImage,
        animation.effect === 'hallokinShadowHero' ? 0 : sourceX,
        animation.effect === 'hallokinShadowHero' ? 0 : sourceY,
        sourceWidth,
        sourceHeight,
        Math.round(facingRight ? -anchorX : -(drawWidth - anchorX)),
        0,
        Math.round(drawWidth),
        Math.round(drawHeight)
    );
    ctx.restore();
}

function showDialogue(name, text, key) {
    const dialogueBox = document.getElementById('dialogueBox');
    const dialogueName = document.getElementById('dialogueName');
    const dialogueText = document.getElementById('dialogueText');
    const dialogueActions = document.getElementById('dialogueActions');
    if (!dialogueBox || !dialogueName || !dialogueText) {
        return;
    }

    dialogueName.textContent = name;
    dialogueText.textContent = text;
    if (dialogueActions) {
        dialogueActions.style.display = 'none';
    }
    dialogueBox.style.display = 'block';
    activeDialogueKey = key;
    activeDialogueMode = 'text';
}

function showUpgradePrompt(name, key) {
    const dialogueBox = document.getElementById('dialogueBox');
    const dialogueName = document.getElementById('dialogueName');
    const dialogueText = document.getElementById('dialogueText');
    const dialogueActions = document.getElementById('dialogueActions');
    if (!dialogueBox || !dialogueName || !dialogueText || !dialogueActions) {
        return;
    }

    dialogueName.textContent = name;
    dialogueText.textContent = 'Do you want to open your upgrade stats before you leave?';
    dialogueActions.style.display = 'flex';
    dialogueBox.style.display = 'block';
    activeDialogueKey = key;
    activeDialogueMode = 'upgrade';
}

function showPortalPrompt(name, key) {
    const dialogueBox = document.getElementById('dialogueBox');
    const dialogueName = document.getElementById('dialogueName');
    const dialogueText = document.getElementById('dialogueText');
    const dialogueActions = document.getElementById('dialogueActions');
    const dialogueYes = document.getElementById('dialogueYes');
    const dialogueNo = document.getElementById('dialogueNo');
    if (!dialogueBox || !dialogueName || !dialogueText || !dialogueActions) {
        return;
    }

    dialogueName.textContent = name;
    if (getTotalWins() >= 3) {
        dialogueText.textContent = 'The portal shakes with a final, violent pull. Beyond it waits the deepest darkness yet. Are you sure you want to step through?';
    } else {
        dialogueText.textContent = 'The portal feels unstable, like it leads somewhere dangerous. Are you sure you want to step through?';
    }
    if (dialogueYes) {
        dialogueYes.textContent = 'Yes';
    }
    if (dialogueNo) {
        dialogueNo.textContent = 'No';
    }
    dialogueActions.style.display = 'flex';
    dialogueBox.style.display = 'block';
    activeDialogueKey = key;
    activeDialogueMode = 'portal';
}

function hideDialogue() {
    const dialogueBox = document.getElementById('dialogueBox');
    const dialogueActions = document.getElementById('dialogueActions');
    if (dialogueBox) {
        dialogueBox.style.display = 'none';
    }
    if (dialogueActions) {
        dialogueActions.style.display = 'none';
    }
    activeDialogueKey = null;
    activeDialogueMode = 'text';
}

function openStatsPanel() {
    const statsPanel = document.getElementById('statsPanel');
    if (!statsPanel) {
        return;
    }

    hideDialogue();
    statsPanel.style.display = 'block';
    refreshStatsPanel();
}

function hideStatsPanel() {
    const statsPanel = document.getElementById('statsPanel');
    if (statsPanel) {
        statsPanel.style.display = 'none';
    }
}

function refreshStatsPanel() {
    const statLabels = {
        health: 'statValueHealth',
        mana: 'statValueMana',
        voidCyclone: 'statValueVoidCyclone',
        shadowStrike: 'statValueShadowStrike'
    };

    Object.entries(statLabels).forEach(([key, id]) => {
        const valueNode = document.getElementById(id);
        if (valueNode) {
            valueNode.textContent = `Lv. ${player.stats[key]} / ${MAX_STAT_LEVEL}`;
        }
    });

    const availablePoints = document.getElementById('availablePoints');
    if (availablePoints) {
        availablePoints.textContent = player.availableStatPoints;
    }

    document.querySelectorAll('.stat-add').forEach((button) => {
        const statKey = button.dataset.stat;
        const statValue = player.stats[statKey] ?? 0;
        button.disabled = player.availableStatPoints <= 0 || statValue >= MAX_STAT_LEVEL;
    });

    const resetButton = document.getElementById('statsReset');
    if (resetButton) {
        resetButton.disabled = getSpentStatPoints() <= 0 || isSavingStats;
    }
}

function getSpentStatPoints() {
    return Object.values(player.stats).reduce((sum, value) => sum + value, 0);
}

function applyDerivedStats() {
    player.maxHealth = 100 + (player.stats.health * 2);
    player.health = Math.min(player.health, player.maxHealth);
    if (player.health <= 0) {
        player.health = player.maxHealth;
    }

    player.maxMana = 100 + (player.stats.mana * 2);
    player.mana = Math.min(player.mana, player.maxMana);
    if (player.mana <= 0) {
        player.mana = player.maxMana;
    }
}

async function upgradeStat(statKey) {
    if (!Object.prototype.hasOwnProperty.call(player.stats, statKey)) {
        return;
    }

    if (!currentUser || !progressApi || isSavingStats) {
        return;
    }

    if (player.availableStatPoints <= 0 || player.stats[statKey] >= MAX_STAT_LEVEL) {
        return;
    }

    isSavingStats = true;
    player.stats[statKey] += 1;
    player.availableStatPoints -= 1;
    applyDerivedStats();
    refreshStatsPanel();
    updateHUD();

    try {
        await progressApi.saveUserProfile(currentUser.uid, {
            level: player.level,
            availablePoints: player.availableStatPoints,
            stats: player.stats
        }, currentUser);
    } finally {
        isSavingStats = false;
        refreshStatsPanel();
    }
}

async function resetStats() {
    if (!currentUser || !progressApi || isSavingStats) {
        return;
    }

    const spentPoints = getSpentStatPoints();
    if (spentPoints <= 0) {
        return;
    }

    isSavingStats = true;
    player.availableStatPoints += spentPoints;
    player.stats = {
        health: 0,
        mana: 0,
        voidCyclone: 0,
        shadowStrike: 0
    };
    applyDerivedStats();
    refreshStatsPanel();
    updateHUD();

    try {
        await progressApi.saveUserProfile(currentUser.uid, {
            level: player.level,
            availablePoints: player.availableStatPoints,
            stats: player.stats
        }, currentUser);
    } finally {
        isSavingStats = false;
        refreshStatsPanel();
    }
}

function updateHUD() {
    const playerLevel = document.getElementById('playerLevel');
    const playerHealth = document.getElementById('playerHealth');
    const playerMana = document.getElementById('playerMana');

    if (playerLevel) {
        playerLevel.textContent = player.level;
    }

    if (playerHealth) {
        playerHealth.textContent = player.health;
    }

    if (playerMana) {
        playerMana.textContent = player.mana;
    }
}

function applyProfileToPlayer(profile) {
    const normalizedProfile = progressApi.normalizeProfile(profile, currentUser);
    currentProfile = normalizedProfile;
    player.level = normalizedProfile.level;
    player.availableStatPoints = normalizedProfile.availablePoints;
    player.stats = {
        health: normalizedProfile.stats.health,
        mana: normalizedProfile.stats.mana,
        voidCyclone: normalizedProfile.stats.voidCyclone,
        shadowStrike: normalizedProfile.stats.shadowStrike
    };
    applyDerivedStats();
    player.health = player.maxHealth;
    player.mana = player.maxMana;
    refreshStatsPanel();
    updateHUD();
}

function getTotalWins() {
    return Math.max(0, Number(currentProfile?.stageProgress?.totalWins) || 0);
}

function getNextStagePath() {
    const totalWins = getTotalWins();

    if (totalWins >= 3) {
        return gameRootPath('stage4.html');
    }

    if (totalWins === 2) {
        return gameRootPath('stage3.html');
    }

    if (totalWins === 1) {
        return gameRootPath('stage2.html');
    }

    return gameRootPath('stage1.html');
}

function showLobbyBanner(title, text) {
    const banner = document.getElementById('lobbyBanner');
    const bannerTitle = document.getElementById('lobbyBannerTitle');
    const bannerText = document.getElementById('lobbyBannerText');
    if (!banner || !bannerTitle || !bannerText) {
        return;
    }

    bannerTitle.textContent = title;
    bannerText.textContent = text;
    banner.style.display = 'block';
    window.clearTimeout(showLobbyBanner.timeoutId);
    showLobbyBanner.timeoutId = window.setTimeout(() => {
        banner.style.display = 'none';
    }, 4200);
}

async function bootstrapAccountState() {
    progressApi = await import(gameRootPath('gameProgress.js'));
    currentUser = await progressApi.requireAuthenticatedUser(gameRootPath('ODYSSEY-main/login.html'));
    let profile;
    try {
        profile = await progressApi.getUserProfile(currentUser.uid, currentUser);
    } catch (error) {
        console.warn('Falling back to a local profile because Firestore could not be loaded:', error);
        profile = progressApi.normalizeProfile({}, currentUser);
    }
    applyProfileToPlayer(profile);

    if (profile.pendingAnnouncement?.message) {
        showLobbyBanner(`Level ${profile.level}`, profile.pendingAnnouncement.message);
        progressApi.clearLobbyAnnouncement(currentUser.uid).catch((error) => {
            console.warn('Failed to clear lobby announcement:', error);
        });
    }
}

function gameLoop(currentTime) {
    const deltaFactor = Math.min((currentTime - lastFrameTime) / 16.67, 1.5);
    lastFrameTime = currentTime;

    if (!paused) {
        updatePlayer(deltaFactor);
        updateNPCs(deltaFactor);
        updateCamera();
        checkNearbyInteractions();
        updateHUD();
    }

    drawBackground();
    drawPlatforms();
    drawBuildings();
    drawObjects();
    drawNPCs();
    drawPlayer();

    requestAnimationFrame(gameLoop);
}

function exitGame() {
    console.log('Thanks for playing The Dark Odyssey!');
}

syncPauseVolume();

bootstrapAccountState()
    .catch((error) => {
        console.error('Failed to bootstrap lobby account state:', error);
        if (!currentUser) {
            window.location.href = gameRootPath('ODYSSEY-main/login.html');
        }
    })
    .finally(() => {
        requestAnimationFrame(gameLoop);
    });
